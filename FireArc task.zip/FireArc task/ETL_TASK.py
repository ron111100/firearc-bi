import pandas as pd
from google.cloud import bigquery

# Retrieve data from the API as a CSV file
url = 'https://data.cityofnewyork.us/resource/8m42-w767.csv?$limit=1000000'
data = pd.read_csv(url)

# Convert incident_datetime column to datetime
data['incident_datetime'] = pd.to_datetime(data['incident_datetime'])

# Create BigQuery client and dataset if not exists
client = bigquery.Client()
dataset_id = 'ron912'
dataset_ref = client.dataset(dataset_id)
dataset = bigquery.Dataset(dataset_ref)
dataset.location = 'US'
try:
    dataset = client.create_dataset(dataset)
except:
    pass


# Create BigQuery table schema for dim_borough_table
dim_table_name = 'dim_borough_table'
dim_table_ref = dataset_ref.table(dim_table_name)
dim_table_schema = [
    bigquery.SchemaField('borough_id', 'INTEGER', mode='REQUIRED', description='Primary key for the table'),
    bigquery.SchemaField('incident_borough', 'STRING', mode='REQUIRED')
]
dim_table = bigquery.Table(dim_table_ref, schema=dim_table_schema)
try:
    dim_table = client.create_table(dim_table)
except:
    pass

# Get unique boroughs and assign borough_id starting from 1
boroughs = data['incident_borough'].unique()
borough_id = 1
borough_id_map = {}
for borough in boroughs:
    borough_id_map[borough] = borough_id
    borough_id += 1

# Add the borough_id column to the data
data['borough_id'] = data['incident_borough'].map(borough_id_map)

# Load data into BigQuery dim_borough_table
dim_table_data = pd.DataFrame({
    'borough_id': range(1, len(boroughs)+1),
    'incident_borough': boroughs
})

dim_table_job_config = bigquery.LoadJobConfig()
dim_table_job_config.write_disposition = 'WRITE_TRUNCATE'
dim_table_job_config.source_format = bigquery.SourceFormat.CSV
dim_table_load_job = client.load_table_from_dataframe(dim_table_data, dim_table, job_config=dim_table_job_config)
dim_table_load_job.result()

print(f'Loaded {dim_table_load_job.output_rows} rows into {dim_table_name}')


# Create BigQuery table schema for dim_alarm_box_table
dim_table_name_2 = 'dim_alarm_box_table'
dim_table_ref_2 = dataset_ref.table(dim_table_name_2)
dim_table_schema_2 = [
    bigquery.SchemaField('alarm_box_id', 'INTEGER', mode='REQUIRED', description='Primary key for the table'),
    bigquery.SchemaField('borough_id', 'INTEGER', mode='REQUIRED', description='Foreign key for the table'),
    bigquery.SchemaField('alarm_box_number', 'INTEGER', mode='REQUIRED'),
    bigquery.SchemaField('alarm_box_location', 'STRING', mode='REQUIRED'),
]

dim_table_2 = bigquery.Table(dim_table_ref_2, schema=dim_table_schema_2)
try:
    dim_table_2 = client.create_table(dim_table_2)
except:
    pass

# Add the borough_id column to the data
data['borough_id'] = data['incident_borough'].map(borough_id_map)

# Select the relevant columns for the dim_alarm_box_table
dim_table_data_2 = data[['alarm_box_number', 'alarm_box_location', 'borough_id']].drop_duplicates()

# Add the alarm_box_id column to the data
dim_table_data_2['alarm_box_id'] = range(1, len(dim_table_data_2)+1)

# Load data into BigQuery dim_alarm_box_table
dim_table_job_config_2 = bigquery.LoadJobConfig()
dim_table_job_config_2.write_disposition = 'WRITE_TRUNCATE'
dim_table_job_config_2.source_format = bigquery.SourceFormat.CSV
dim_table_load_job_2 = client.load_table_from_dataframe(dim_table_data_2, dim_table_2, job_config=dim_table_job_config_2)
dim_table_load_job_2.result()

print(f'Loaded {dim_table_load_job_2.output_rows} rows into {dim_table_name_2}')



# Create BigQuery table schema for stg fact table
df = pd.DataFrame(data)

fact_table_name = 'stg_fact_incident_table'
fact_table_ref = client.dataset('ron912').table(fact_table_name)

# Define fact table schema
fact_table_schema = [
    bigquery.SchemaField('key_fact_incident_id', 'INTEGER', mode='REQUIRED', description='Primary key for the table'),
    bigquery.SchemaField('starfire_incident_id', 'INTEGER', mode='REQUIRED'),
    bigquery.SchemaField('incident_datetime', 'DATETIME', mode='REQUIRED'),
    bigquery.SchemaField('borough_id', 'INTEGER', mode='REQUIRED', description='Foreign key for the table'),
    bigquery.SchemaField('alarm_box_id', 'INTEGER', mode='REQUIRED', description='Foreign key for the table'),
    bigquery.SchemaField('alarm_source_description_tx', 'STRING'),
    bigquery.SchemaField('alarm_level_index_description','STRING'),
    bigquery.SchemaField('highest_alarm_level','STRING'),
    bigquery.SchemaField('incident_classification','STRING'),
    bigquery.SchemaField('incident_classification_group','STRING'),
    bigquery.SchemaField('dispatch_response_seconds_qy','INTEGER'),
    bigquery.SchemaField('first_assignment_datetime','STRING'),
    bigquery.SchemaField('first_activation_datetime','STRING'),
    bigquery.SchemaField('first_on_scene_datetime','STRING'),
    bigquery.SchemaField('incident_close_datetime','STRING')

]

# Create fact table with schema
fact_table = bigquery.Table(fact_table_ref, schema=fact_table_schema)
try:
    fact_table = client.create_table(fact_table)
except:
    pass

# Define dimension table references
borough_dim_table_ref = client.dataset('ron912').table('dim_borough_table')
alarm_box_dim_table_ref = client.dataset('ron912').table('dim_alarm_box_table')


# Merge data with dimension tables to get foreign keys
df_borough = client.query(f"SELECT borough_id, incident_borough FROM `{borough_dim_table_ref}`").to_dataframe()
df_alarm_box = client.query(f"SELECT alarm_box_id, borough_id, alarm_box_location, alarm_box_number FROM `{alarm_box_dim_table_ref}`").to_dataframe()

df = pd.merge(df, df_borough, on='borough_id', how='left')
df = pd.merge(df, df_alarm_box, on=['borough_id', 'alarm_box_location','alarm_box_number'], how='left') # modify this line


# Add primary key and foreign keys to DataFrame
df['key_fact_incident_id'] = df.index + 1
df['borough_id'] = df['borough_id'].astype(int)
df['alarm_box_id'] = df['alarm_box_id'].astype(int)


new_df = df.loc[:, ['key_fact_incident_id','starfire_incident_id' ,'incident_datetime', 
                    'borough_id', 'alarm_box_id', 'alarm_source_description_tx', 
                    'alarm_level_index_description', 'highest_alarm_level', 
                    'incident_classification', 'incident_classification_group', 
                    'dispatch_response_seconds_qy', 'first_assignment_datetime', 
                    'first_activation_datetime', 'first_on_scene_datetime', 
                    'incident_close_datetime']]


# Define BigQuery job configuration for fact table load job
fact_table_job_config = bigquery.LoadJobConfig()
fact_table_job_config.write_disposition = 'WRITE_TRUNCATE'
fact_table_job_config.autodetect = True
fact_table_job_config.source_format = bigquery.SourceFormat.CSV

# Load data into BigQuery fact table
fact_table_load_job = client.load_table_from_dataframe(new_df, fact_table_ref, job_config=fact_table_job_config)
fact_table_load_job.result()
print(f'Loaded {fact_table_load_job.output_rows} rows into {fact_table_name}')


# Create BigQuery table schema for dwh_fact_incident_table_without_idx
fact_table_name='dwh_fact_incident_table_without_par'
create_table_query = """
CREATE TABLE ron912.dwh_fact_incident_table_without_par (
  key_fact_incident_id INT64 NOT NULL,
  starfire_incident_id INT64 NOT NULL,
  incident_datetime DATETIME NOT NULL,
  borough_id INT64 NOT NULL,
  alarm_box_id INT64 NOT NULL,
  alarm_source_description_tx STRING,
  alarm_level_index_description STRING,
  highest_alarm_level STRING,
  incident_classification STRING,
  incident_classification_group STRING,
  dispatch_response_seconds_qy INT64,
  first_assignment_datetime STRING,
  first_activation_datetime STRING,
  first_on_scene_datetime STRING,
  incident_close_datetime STRING,
  dwh_updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
)
"""

# Execute the query to create the new table
query_job = client.query(create_table_query)
query_job.result()

# Define the SQL query to insert data into the new table
insert_query = """
INSERT INTO ron912.dwh_fact_incident_table_without_par (
  key_fact_incident_id,
  starfire_incident_id,
  incident_datetime,
  borough_id,
  alarm_box_id,
  alarm_source_description_tx,
  alarm_level_index_description,
  highest_alarm_level,
  incident_classification,
  incident_classification_group,
  dispatch_response_seconds_qy,
  first_assignment_datetime,
  first_activation_datetime,
  first_on_scene_datetime,
  incident_close_datetime
)
SELECT
  key_fact_incident_id,
  starfire_incident_id,
  incident_datetime,
  borough_id,
  alarm_box_id,
  alarm_source_description_tx,
  alarm_level_index_description,
  highest_alarm_level,
  incident_classification,
  incident_classification_group,
  dispatch_response_seconds_qy,
  first_assignment_datetime,
  first_activation_datetime,
  first_on_scene_datetime,
  incident_close_datetime
FROM ron912.stg_fact_incident_table
"""

# Execute the query to insert data into the new table
query_job = client.query(insert_query)
query_job.result()
print(f'Loaded rows into {fact_table_name}')




# Create BigQuery table schema for dwh_fact_incident_table_with_idx
fact_table_name='dwh_fact_incident_table_with_par'
create_table_query = """
CREATE TABLE ron912.dwh_fact_incident_table_with_par (
  key_fact_incident_id INT64 NOT NULL,
  starfire_incident_id INT64 NOT NULL,
  incident_datetime DATETIME NOT NULL,
  borough_id INT64 NOT NULL,
  alarm_box_id INT64 NOT NULL,
  alarm_source_description_tx STRING,
  alarm_level_index_description STRING,
  highest_alarm_level STRING,
  incident_classification STRING,
  incident_classification_group STRING,
  dispatch_response_seconds_qy INT64,
  first_assignment_datetime STRING,
  first_activation_datetime STRING,
  first_on_scene_datetime STRING,
  incident_close_datetime STRING,
  dwh_updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
)
PARTITION BY DATE(incident_datetime)
"""

# Execute the query to create the new table
query_job = client.query(create_table_query)
query_job.result()

# Define the SQL query to insert data into the new table
insert_query = """
INSERT INTO ron912.dwh_fact_incident_table_with_par (
  key_fact_incident_id,
  starfire_incident_id,
  incident_datetime,
  borough_id,
  alarm_box_id,
  alarm_source_description_tx,
  alarm_level_index_description,
  highest_alarm_level,
  incident_classification,
  incident_classification_group,
  dispatch_response_seconds_qy,
  first_assignment_datetime,
  first_activation_datetime,
  first_on_scene_datetime,
  incident_close_datetime
)
SELECT
  key_fact_incident_id,
  starfire_incident_id,
  incident_datetime,
  borough_id,
  alarm_box_id,
  alarm_source_description_tx,
  alarm_level_index_description,
  highest_alarm_level,
  incident_classification,
  incident_classification_group,
  dispatch_response_seconds_qy,
  first_assignment_datetime,
  first_activation_datetime,
  first_on_scene_datetime,
  incident_close_datetime
FROM ron912.stg_fact_incident_table
"""

# Execute the query to insert data into the new table
query_job = client.query(insert_query)
query_job.result()

print(f'Loaded rows into {fact_table_name}')


